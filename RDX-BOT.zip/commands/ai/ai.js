// commands/ai/ai.js
import OpenAI from "openai";
import api from "../../config/api.js";

function client() {
  if (!api.openai.apiKey) throw new Error("OPENAI_API_KEY belum diisi di .env");
  return new OpenAI({ apiKey: api.openai.apiKey, baseURL: api.openai.baseURL });
}

export default [
  {
    name: "ai", aliases: ["chatgpt", "ask"], category: "ai", limit: 2,
    async run({ sock, jid, q }) {
      if (!q) return sock.sendMessage(jid, { text: "Tulis pertanyaan." });
      const oa = client();
      const res = await oa.chat.completions.create({
        model: api.openai.model,
        messages: [{ role: "user", content: q }],
      });
      await sock.sendMessage(jid, { text: res.choices[0].message.content });
    },
  },
  {
    name: "translate", category: "ai", limit: 2,
    async run({ sock, jid, q }) {
      const [lang, ...rest] = q.split(" ");
      if (!lang || !rest.length) return sock.sendMessage(jid, { text: "Format: .translate en Halo dunia" });
      const oa = client();
      const res = await oa.chat.completions.create({
        model: api.openai.model,
        messages: [{ role: "user", content: `Terjemahkan ke bahasa ${lang}: ${rest.join(" ")}` }],
      });
      await sock.sendMessage(jid, { text: res.choices[0].message.content });
    },
  },
  {
    name: "tts", category: "ai", limit: 3,
    async run({ sock, jid, q }) {
      if (!q) return sock.sendMessage(jid, { text: "Tulis teks untuk dijadikan suara." });
      const oa = client();
      const mp3 = await oa.audio.speech.create({
        model: api.openai.ttsModel,
        voice: "alloy",
        input: q,
      });
      const buf = Buffer.from(await mp3.arrayBuffer());
      await sock.sendMessage(jid, { audio: buf, mimetype: "audio/mpeg", ptt: true });
    },
  },
  {
    name: "vision", category: "ai", limit: 3,
    async run({ sock, msg, jid, q }) {
      if (msg.type !== "imageMessage") return sock.sendMessage(jid, { text: "Kirim gambar dengan caption .vision pertanyaan" });
      const buf = await sock.downloadMediaMessage(msg.raw);
      const b64 = buf.toString("base64");
      const oa = client();
      const res = await oa.chat.completions.create({
        model: api.openai.visionModel,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: q || "Jelaskan gambar ini." },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${b64}` } },
          ],
        }],
      });
      await sock.sendMessage(jid, { text: res.choices[0].message.content });
    },
  },
];