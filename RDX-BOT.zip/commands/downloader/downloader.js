// commands/downloader/downloader.js
import { tiktok, instagram, facebook, twitter, youtube } from "../../lib/downloader.js";
import { isUrl } from "../../lib/functions.js";

async function sendMedia(sock, jid, media, caption = "") {
  if (media.type === "video") {
    await sock.sendMessage(jid, { video: { url: media.url }, caption });
  } else if (media.type === "image") {
    await sock.sendMessage(jid, { image: { url: media.url }, caption });
  }
}

export default [
  {
    name: "tiktok", aliases: ["tt"], category: "downloader", limit: 1,
    async run({ sock, jid, q }) {
      if (!isUrl(q)) return sock.sendMessage(jid, { text: "Kirim URL TikTok." });
      const r = await tiktok(q);
      await sendMedia(sock, jid, r, `🎵 ${r.title || ""}\n👤 ${r.author || ""}`);
    },
  },
  {
    name: "instagram", aliases: ["ig"], category: "downloader", limit: 1,
    async run({ sock, jid, q }) {
      if (!isUrl(q)) return sock.sendMessage(jid, { text: "Kirim URL Instagram." });
      const list = await instagram(q);
      for (const m of list.slice(0, 10)) {
        await sendMedia(sock, jid, m, "📸 Instagram");
      }
    },
  },
  {
    name: "facebook", aliases: ["fb"], category: "downloader", limit: 1,
    async run({ sock, jid, q }) {
      if (!isUrl(q)) return sock.sendMessage(jid, { text: "Kirim URL Facebook." });
      const r = await facebook(q);
      await sendMedia(sock, jid, r, "📘 Facebook");
    },
  },
  {
    name: "twitter", aliases: ["x"], category: "downloader", limit: 1,
    async run({ sock, jid, q }) {
      if (!isUrl(q)) return sock.sendMessage(jid, { text: "Kirim URL Twitter/X." });
      const r = await twitter(q);
      await sendMedia(sock, jid, r, `🐦 ${r.desc || ""}`);
    },
  },
  {
    name: "youtube", aliases: ["yt"], category: "downloader", limit: 1,
    async run({ sock, jid, q }) {
      if (!isUrl(q)) return sock.sendMessage(jid, { text: "Kirim URL YouTube." });
      const r = await youtube(q);
      await sendMedia(sock, jid, r, `▶️ ${r.title || ""}`);
    },
  },
];