// commands/owner/owner.js
import setting from "../../config/setting.js";
import { setUser, getUser } from "../../lib/database.js";
import { getSocket } from "../../lib/connection.js";

export default [
  {
    name: "owner", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, jid }) {
      await sock.sendMessage(jid, { text: `👑 Owner: ${setting.ownerName}\n📞 ${setting.ownerNumber}` });
    },
  },
  {
    name: "setprefix", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, jid, q }) {
      if (!q || q.length > 3) return sock.sendMessage(jid, { text: "Prefix 1–3 karakter." });
      setting.prefix = q;
      await sock.sendMessage(jid, { text: `✅ Prefix diubah ke "${q}" (berlaku selama proses berjalan).` });
    },
  },
  {
    name: "broadcast", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, jid, q }) {
      if (!q) return sock.sendMessage(jid, { text: "Tulis pesan broadcast." });
      const chats = await sock.groupFetchAllParticipating();
      const groups = Object.keys(chats);
      for (const g of groups) {
        try {
          await sock.sendMessage(g, { text: `📢 *BROADCAST*\n\n${q}` });
        } catch {}
      }
      await sock.sendMessage(jid, { text: `✅ Broadcast terkirim ke ${groups.length} grup.` });
    },
  },
  {
    name: "block", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, msg, jid, q }) {
      const target = msg.raw.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || q;
      if (!target) return sock.sendMessage(jid, { text: "Tag target." });
      await sock.updateBlockStatus(target, "block");
      await sock.sendMessage(jid, { text: "✅ Diblokir." });
    },
  },
  {
    name: "unblock", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, msg, jid, q }) {
      const target = msg.raw.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || q;
      if (!target) return sock.sendMessage(jid, { text: "Tag target." });
      await sock.updateBlockStatus(target, "unblock");
      await sock.sendMessage(jid, { text: "✅ Dibuka blokirnya." });
    },
  },
  {
    name: "restart", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, jid }) {
      await sock.sendMessage(jid, { text: "🔄 Merestart bot..." });
      setTimeout(() => process.exit(0), 1000);
    },
  },
  {
    name: "maintenance", category: "owner", ownerOnly: true, limit: 0,
    async run({ sock, jid, q }) {
      const mode = q?.toLowerCase();
      if (mode !== "on" && mode !== "off") return sock.sendMessage(jid, { text: ".maintenance on/off" });
      setting.maintenance = mode === "on";
      await sock.sendMessage(jid, { text: `🔧 Maintenance ${mode}.` });
    },
  },
  {
    name: "eval", category: "owner", ownerOnly: true, limit: 0, disabled: true,
    async run({ sock, jid }) {
      await sock.sendMessage(jid, { text: "❌ Eval dinonaktifkan." });
    },
  },
];