// commands/group/group.js
import { getGroup, setGroup } from "../../lib/database.js";

function toggle(field) {
  return {
    name: field, category: "group", adminOnly: true, limit: 0,
    async run({ sock, jid, q }) {
      const val = q?.toLowerCase();
      if (val !== "on" && val !== "off") {
        return sock.sendMessage(jid, { text: `Format: .${field} on/off` });
      }
      setGroup(jid, field, val === "on" ? 1 : 0);
      await sock.sendMessage(jid, { text: `✅ ${field} ${val}.` });
    },
  };
}

export default [
  toggle("welcome"),
  toggle("goodbye"),
  toggle("antilink"),
  toggle("antispam"),
  {
    name: "kick", category: "group", adminOnly: true, limit: 0,
    async run({ sock, msg, jid, q }) {
      const target = msg.raw.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || q;
      if (!target) return sock.sendMessage(jid, { text: "Tag atau tulis nomor target." });
      await sock.groupParticipantsUpdate(jid, [target], "remove");
      await sock.sendMessage(jid, { text: "✅ Anggota dikeluarkan." });
    },
  },
  {
    name: "promote", category: "group", adminOnly: true, limit: 0,
    async run({ sock, msg, jid, q }) {
      const target = msg.raw.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || q;
      if (!target) return sock.sendMessage(jid, { text: "Tag target." });
      await sock.groupParticipantsUpdate(jid, [target], "promote");
      await sock.sendMessage(jid, { text: "✅ Dipromosikan menjadi admin." });
    },
  },
  {
    name: "demote", category: "group", adminOnly: true, limit: 0,
    async run({ sock, msg, jid, q }) {
      const target = msg.raw.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || q;
      if (!target) return sock.sendMessage(jid, { text: "Tag target." });
      await sock.groupParticipantsUpdate(jid, [target], "demote");
      await sock.sendMessage(jid, { text: "✅ Diturunkan dari admin." });
    },
  },
  {
    name: "tagall", category: "group", adminOnly: true, limit: 0,
    async run({ sock, jid, q }) {
      const meta = await sock.groupMetadata(jid);
      const mentions = meta.participants.map((p) => p.id);
      const text = (q || "📢 Pengumuman") + "\n\n" + mentions.map((m) => `@${m.split("@")[0]}`).join(" ");
      await sock.sendMessage(jid, { text, mentions });
    },
  },
];