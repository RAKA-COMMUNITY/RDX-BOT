// commands/utility/utility.js
import os from "os";
import moment from "moment-timezone";
import axios from "axios";
import setting from "../../config/setting.js";
import { formatRuntime } from "../../lib/functions.js";

const startTime = Date.now();

export default [
  {
    name: "menu", aliases: ["help"], category: "utility", limit: 0,
    async run({ sock, jid, commands }) {
      const cats = {};
      for (const [, c] of commands) {
        if (!cats[c.category]) cats[c.category] = [];
        cats[c.category].push(`${setting.prefix}${c.name}`);
      }
      let text = `${setting.menuHeader}\n`;
      text += `🤖 ${setting.botName}\n`;
      text += `📅 ${moment().tz("Asia/Jakarta").format("DD MMM YYYY HH:mm")}\n`;
      text += `⏱️ Runtime: ${formatRuntime(Date.now() - startTime)}\n\n`;
      for (const [cat, list] of Object.entries(cats)) {
        text += `*${cat.toUpperCase()}*\n${list.join(", ")}\n\n`;
      }
      text += setting.menuFooter;
      await sock.sendMessage(jid, { text });
    },
  },
  {
    name: "ping", category: "utility", limit: 0,
    async run({ sock, jid }) {
      const t = Date.now();
      await sock.sendMessage(jid, { text: "🏓 Pong!" });
      await sock.sendMessage(jid, { text: `⏱️ ${Date.now() - t} ms` });
    },
  },
  {
    name: "runtime", category: "utility", limit: 0,
    async run({ sock, jid }) {
      await sock.sendMessage(jid, { text: `⏱️ Runtime: ${formatRuntime(Date.now() - startTime)}` });
    },
  },
  {
    name: "info", category: "utility", limit: 0,
    async run({ sock, jid }) {
      const m = process.memoryUsage();
      await sock.sendMessage(jid, {
        text: `🤖 ${setting.botName}\nPlatform: ${os.platform()} ${os.arch()}\nRAM: ${(m.rss / 1024 / 1024).toFixed(1)} MB\nNode: ${process.version}`,
      });
    },
  },
  {
    name: "calc", category: "utility", limit: 0,
    async run({ sock, jid, q }) {
      if (!q) return sock.sendMessage(jid, { text: "Contoh: .calc 2+2*3" });
      // Evaluasi aman tanpa eval: hanya angka dan operator
      if (!/^[\d\s+\-*/().%]+$/.test(q)) {
        return sock.sendMessage(jid, { text: "❌ Ekspresi tidak valid." });
      }
      try {
        // Gunakan Function terbatas, bukan eval langsung
        const result = Function(`"use strict"; return (${q});`)();
        await sock.sendMessage(jid, { text: `🧮 ${q} = ${result}` });
      } catch {
        await sock.sendMessage(jid, { text: "❌ Gagal menghitung." });
      }
    },
  },
  {
    name: "weather", category: "utility", limit: 1,
    async run({ sock, jid, q, args }) {
      if (!q) return sock.sendMessage(jid, { text: "Contoh: .weather Jakarta" });
      const key = (await import("../../config/api.js")).default.weather.apiKey;
      if (!key) return sock.sendMessage(jid, { text: "API cuaca belum dikonfigurasi." });
      const { data } = await axios.get("https://api.openweathermap.org/data/2.5/weather", {
        params: { q, appid: key, units: "metric" },
      });
      await sock.sendMessage(jid, {
        text: `🌤️ ${data.name}\nSuhu: ${data.main.temp}°C\nCuaca: ${data.weather[0].description}`,
      });
    },
  },
];