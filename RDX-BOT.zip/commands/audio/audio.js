// commands/audio/audio.js
import ffmpeg from "fluent-ffmpeg";
import fs from "fs";
import path from "path";
import { downloadToFile, cleanupTemp } from "../../lib/functions.js";
import setting from "../../config/setting.js";

const effects = {
  bass: "bass=g=10",
  volume: "volume=2.0",
  slow: "atempo=0.8",
  fast: "atempo=1.25",
  reverse: "areverse",
  reverb: "aecho=0.8:0.9:1000:0.3",
  echo: "aecho=0.8:0.88:60:0.4",
  robot: "aecho=0.8:0.88:6:0.4",
  chipmunk: "asetrate=44100*1.5,aresample=44100",
  deep: "asetrate=44100*0.7,aresample=44100",
  nightcore: "asetrate=44100*1.25,aresample=44100",
  daycore: "asetrate=44100*0.85,aresample=44100",
  "8d": "apulsator=hz=0.1",
  blown: "volume=5.0",
  smooth: "lowpass=f=3000",
  distortion: "volume=3.0,alimiter",
  normalize: "loudnorm",
  treble: "treble=g=10",
  vocal: "highpass=f=200,lowpass=f=3000",
  karaoke: "pan=stereo|c0=c0-c1|c1=c1-c0",
  pitch: "asetrate=44100*1.2,aresample=44100",
  low: "lowpass=f=500",
  high: "highpass=f=3000",
  flanger: "flanger",
  chorus: "chorus=0.7:0.9:55:0.4:0.25:2",
  phaser: "aphaser",
  compressor: "acompressor",
  fade: "afade=t=in:ss=0:d=3",
  mono: "pan=mono|c0=0.5*c0+0.5*c1",
  stereo: "pan=stereo|c0=c0|c1=c1",
};

async function applyEffect(sock, msg, jid, filter) {
  if (msg.type !== "audioMessage") {
    return sock.sendMessage(jid, { text: "Reply pesan audio dengan command ini." });
  }
  const buf = await sock.downloadMediaMessage(msg.raw);
  const inp = path.join(setting.tempDir, `in_${Date.now()}.ogg`);
  const out = path.join(setting.tempDir, `out_${Date.now()}.ogg`);
  fs.writeFileSync(inp, buf);

  await new Promise((res, rej) => {
    ffmpeg(inp)
      .audioFilters(filter)
      .on("end", res)
      .on("error", rej)
      .save(out);
  });

  const outBuf = fs.readFileSync(out);
  await sock.sendMessage(jid, { audio: outBuf, mimetype: "audio/ogg; codecs=opus", ptt: true });
  fs.unlinkSync(inp); fs.unlinkSync(out);
  cleanupTemp();
}

const cmds = Object.entries(effects).map(([name, filter]) => ({
  name,
  category: "audio",
  limit: 1,
  async run({ sock, msg, jid }) {
    await applyEffect(sock, msg, jid, filter);
  },
}));

cmds.push({
  name: "tomp3",
  category: "audio",
  limit: 1,
  async run({ sock, msg, jid }) {
    if (msg.type !== "videoMessage" && msg.type !== "audioMessage") {
      return sock.sendMessage(jid, { text: "Reply video/audio." });
    }
    const buf = await sock.downloadMediaMessage(msg.raw);
    const inp = path.join(setting.tempDir, `v_${Date.now()}`);
    const out = path.join(setting.tempDir, `a_${Date.now()}.mp3`);
    fs.writeFileSync(inp, buf);
    await new Promise((res, rej) => {
      ffmpeg(inp).toFormat("mp3").on("end", res).on("error", rej).save(out);
    });
    await sock.sendMessage(jid, { audio: fs.readFileSync(out), mimetype: "audio/mpeg" });
    fs.unlinkSync(inp); fs.unlinkSync(out);
  },
});

export default cmds;