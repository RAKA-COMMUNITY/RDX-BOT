// commands/image/image.js
import sharp from "sharp";
import setting from "../../config/setting.js";

async function editImage(sock, msg, jid, fn, caption) {
  if (msg.type !== "imageMessage") {
    return sock.sendMessage(jid, { text: "Reply gambar dengan command ini." });
  }
  const buf = await sock.downloadMediaMessage(msg.raw);
  const out = await fn(sharp(buf));
  await sock.sendMessage(jid, { image: out, caption });
}

export default [
  {
    name: "blur", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, (s) => s.blur(10).toBuffer(), "🌫️ Blur");
    },
  },
  {
    name: "sharpen", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, (s) => s.sharpen().toBuffer(), "🔪 Sharpen");
    },
  },
  {
    name: "grayscale", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, (s) => s.grayscale().toBuffer(), "⚫ Grayscale");
    },
  },
  {
    name: "invert", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, (s) => s.negate().toBuffer(), "🔄 Invert");
    },
  },
  {
    name: "brightness", category: "image", limit: 1,
    async run({ sock, msg, jid, q }) {
      const val = Math.min(Math.max(parseFloat(q) || 1.2, 0.1), 3);
      await editImage(sock, msg, jid, (s) => s.modulate({ brightness: val }).toBuffer(), `☀️ Brightness ${val}`);
    },
  },
  {
    name: "contrast", category: "image", limit: 1,
    async run({ sock, msg, jid, q }) {
      const val = Math.min(Math.max(parseFloat(q) || 1.5, 0.1), 3);
      await editImage(sock, msg, jid, (s) => s.linear(val, -(128 * val) + 128).toBuffer(), `🎚️ Contrast ${val}`);
    },
  },
  {
    name: "pixelate", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, async (s) => {
        const meta = await s.metadata();
        const w = Math.max(8, Math.round((meta.width || 100) / 20));
        return s.resize(w, null).resize(meta.width, meta.height, { kernel: "nearest" }).toBuffer();
      }, "🧩 Pixelate");
    },
  },
  {
    name: "circle", category: "image", limit: 1,
    async run({ sock, msg, jid }) {
      await editImage(sock, msg, jid, async (s) => {
        const meta = await s.metadata();
        const size = Math.min(meta.width || 512, meta.height || 512);
        const mask = Buffer.from(`<svg width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${size/2}" fill="white"/></svg>`);
        return s.resize(size, size).composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
      }, "⭕ Circle");
    },
  },
  {
    name: "removebg", category: "image", limit: 2,
    async run({ sock, jid }) {
      await sock.sendMessage(jid, { text: "Fitur removebg memerlukan API eksternal. Konfigurasikan endpoint di config/api.js." });
    },
  },
];