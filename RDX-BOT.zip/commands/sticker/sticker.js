// commands/sticker/sticker.js
import { Sticker } from "wa-sticker-formatter";
import { downloadToBuffer } from "../../lib/functions.js";
import setting from "../../config/setting.js";

async function makeSticker(input, opts = {}) {
  const st = new Sticker(input, {
    pack: setting.botName,
    author: setting.ownerName,
    ...opts,
  });
  await st.build();
  return st.get();
}

export default [
  {
    name: "sticker", aliases: ["s"], category: "sticker", limit: 1,
    async run({ sock, msg, jid }) {
      if (!msg.isMedia) return sock.sendMessage(jid, { text: "Kirim gambar/video pendek." });
      const media = msg.raw.message;
      const type = msg.type;
      if (type === "videoMessage" && media.videoMessage.seconds > setting.maxVideoDurationSec) {
        return sock.sendMessage(jid, { text: "Video terlalu panjang untuk sticker animasi." });
      }
      const buf = await sock.downloadMediaMessage(msg.raw);
      const webp = await makeSticker(buf, { animated: type === "videoMessage" });
      await sock.sendMessage(jid, { sticker: webp });
    },
  },
  {
    name: "brat", category: "sticker", limit: 1,
    async run({ sock, jid, q }) {
      if (!q) return sock.sendMessage(jid, { text: "Tulis teks untuk sticker brat." });
      // Brat: teks hitam di background putih sederhana via sharp
      const sharp = (await import("sharp")).default;
      const svg = `<svg width="512" height="512"><rect width="100%" height="100%" fill="white"/><text x="50%" y="50%" font-size="48" text-anchor="middle" dominant-baseline="middle" fill="black">${q.replace(/[<>&]/g, "")}</text></svg>`;
      const buf = await sharp(Buffer.from(svg)).png().toBuffer();
      const webp = await makeSticker(buf);
      await sock.sendMessage(jid, { sticker: webp });
    },
  },
  {
    name: "toimg", category: "sticker", limit: 1,
    async run({ sock, msg, jid }) {
      if (msg.type !== "stickerMessage") return sock.sendMessage(jid, { text: "Reply sticker." });
      const buf = await sock.downloadMediaMessage(msg.raw);
      await sock.sendMessage(jid, { image: buf, caption: "✅ Sticker → Gambar" });
    },
  },
  {
    name: "take", category: "sticker", limit: 1,
    async run({ sock, msg, jid, q }) {
      if (msg.type !== "stickerMessage") return sock.sendMessage(jid, { text: "Reply sticker." });
      const [pack, author] = q.split("|").map((s) => s?.trim());
      const buf = await sock.downloadMediaMessage(msg.raw);
      const webp = await makeSticker(buf, { pack: pack || setting.botName, author: author || setting.ownerName });
      await sock.sendMessage(jid, { sticker: webp });
    },
  },
];