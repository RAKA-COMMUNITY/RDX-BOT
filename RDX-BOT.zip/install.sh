#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "╭─────────────────────────────────────╮"
echo "│  RDX WhatsApp Bot — Installer Termux │"
echo "╰─────────────────────────────────────╯"

# 1. Update & dependency sistem
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git ffmpeg python make clang pkg-config libvips xorgproto

# 2. Pastikan libvips terdeteksi
if ! pkg-config --modversion vips-cpp >/dev/null 2>&1; then
  echo "[!] libvips tidak terdeteksi. Coba: pkg install libvips"
  exit 1
fi

# 3. Install dependency Node (lewati script native dulu)
npm install --ignore-scripts

# 4. Rebuild sharp dengan libvips Termux
export SHARP_FORCE_GLOBAL_LIBVIPS=1
npm rebuild sharp

# 5. Pastikan better-sqlite3-termux terpasang
npm rebuild @mmmbuto/better-sqlite3-termux 2>/dev/null || true

# 6. Salin .env
if [ ! -f .env ]; then
  cp .env.example .env
  echo "[i] File .env dibuat. Isi API key sebelum menjalankan bot."
fi

echo "[✓] Instalasi selesai. Jalankan: bash start.sh"