# RDX WhatsApp Bot

Bot WhatsApp multifungsi yang berjalan langsung di **Termux Android** tanpa VPS, tanpa hosting, dan tanpa komputer.

## Persyaratan
- Android 8+ (ARM64)
- Termux terbaru dari F-Droid
- Node.js ≥ 20
- FFmpeg, libvips, Python, Make, Clang

## Instalasi Cepat
```bash
pkg update && pkg upgrade -y
pkg install nodejs-lts git ffmpeg python make clang pkg-config libvips xorgproto -y
git clone <repo-anda> RDX-BOT && cd RDX-BOT
bash install.sh
cp .env.example .env
nano .env          # isi OWNER_NUMBER dan API key
bash start.sh