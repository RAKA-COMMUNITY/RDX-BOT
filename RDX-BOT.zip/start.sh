#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
node index.js