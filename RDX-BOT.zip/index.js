// index.js
import "dotenv/config";
import { connectToWhatsApp, getSocket } from "./lib/connection.js";
import { serializeMessage } from "./lib/serializer.js";
import { handleCommand } from "./lib/handler.js";
import { cleanupTemp } from "./lib/functions.js";
import setting from "./config/setting.js";

console.log(`[i] Menjalankan ${setting.botName}...`);

// Bersihkan temp setiap 5 menit
setInterval(cleanupTemp, 5 * 60 * 1000);

async function main() {
  await connectToWhatsApp(async (sock, rawMsg) => {
    const msg = serializeMessage(rawMsg);
    if (!msg) return;
    if (!msg.text && !msg.isMedia) return;

    await handleCommand(sock, msg);
  });
}

main().catch((e) => {
  console.error("[fatal]", e);
  process.exit(1);
});