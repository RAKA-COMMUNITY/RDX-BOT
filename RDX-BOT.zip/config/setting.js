// config/setting.js
export default {
  botName: "RDX WhatsApp Bot",
  ownerName: "RDX Owner",
  ownerNumber: process.env.OWNER_NUMBER || "6289513097656",
  prefix: ".",
  sessionDir: "./sessions",
  databaseDir: "./database",
  tempDir: "./temp",

  // ── Login method ──────────────────────────
  // "qr"      = scan QR di terminal (default)
  // "pairing" = masukkan nomor, dapat kode 8 digit
  loginMethod: process.env.LOGIN_METHOD || "qr",
  // Nomor untuk pairing (kosongkan → akan diminta via terminal)
  pairingNumber: process.env.PAIRING_NUMBER || "",

  // Batas keamanan
  maxFileSizeMB: 50,
  maxVideoDurationSec: 10,
  requestTimeoutMs: 30000,
  cooldownMs: 3000,

  // Fitur grup default
  welcome: { enabled: false, text: "Selamat datang @user di @group 👋" },
  goodbye: { enabled: false, text: "Selamat tinggal @user 👋" },
  antilink: { enabled: false },
  antispam: { enabled: false },

  // Menu kustom
  menuHeader: "╭━━━「 *RDX WHATSAPP BOT* 」━━━╮",
  menuFooter: "╰━━━━━━━━━━━━━━━━━━━━━━╯\n> Powered by RDX • Termux Ready",
};