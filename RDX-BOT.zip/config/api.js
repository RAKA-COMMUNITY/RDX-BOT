// config/api.js
// API key TIDAK ditulis di source code. Semua diambil dari .env
export default {
  openai: {
    apiKey: process.env.OPENAI_API_KEY || "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",
    baseURL: process.env.OPENAI_BASE_URL || "https://api.openai.com/v1",
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    ttsModel: process.env.OPENAI_TTS_MODEL || "tts-1",
    visionModel: process.env.OPENAI_VISION_MODEL || "gpt-4o-mini",
  },
  gemini: {
    apiKey: process.env.GEMINI_API_KEY || "AQ.Ab8RN6LNUwcTcxYE8lN87RydYYzJr6uuhI1ejTd1PIs2RKNEgQ",
    model: process.env.GEMINI_MODEL || "gemini-1.5-flash",
  },
  weather: {
    apiKey: process.env.WEATHER_API_KEY || "",
    baseURL: "https://api.openweathermap.org/data/2.5/weather",
  },
  shortlink: {
    apiKey: process.env.SHORTLINK_API_KEY || "",
    baseURL: process.env.SHORTLINK_BASE_URL || "https://api.short.io/links",
  },
};